# 运行契约 · 1.0.0

## 范围与接口

`runStandard(input, adapter)` 提供 `ORDER` 与 `PAYMENT`。标准适配器来自 `createLiveAdapter(helpers, {taskId})`，声明 `commitProtocol: BEFORE_FINAL_CLICK`。

| 参数 | 含义 |
|---|---|
| operation | ORDER（默认）或 PAYMENT |
| taskId | ORDER 首次必填的稳定批次标识；同值不能改订单集合 |
| orderIds | ORDER 为完整原集合，最多 20 单且不重复；PAYMENT 可省略或指定原批次子集 |
| batchRef | PAYMENT 必须能解析到原授权记录；可用原 taskId 找到相同引用 |
| stateDir | 可选的运行记录目录；优先于 XHS_STATE_DIR，再退至默认目录 |
| preview | true 时停在最终动作前；首次走查批次永久只读 |
| conversationState | 可选引用提示，schema 2 返回批次引用；不代替磁盘记录或平台事实 |

不再接收付款事件作为执行门槛。支付入口不能创建授权批次，不能创建合作或补回填；未知引用、越界子集与变更原集合均拒绝。

## 操作记录

运行目录包含 `batches/`（原授权集合）、`orders/`（跨批次共用的逐单任务映射及未决动作）和 `locks/`。目录权限 0700，JSON 权限 0600；临时文件写入、fsync、原子 rename、目录 fsync。记录不含登录凭据，不使用数据库或钥匙串。

最终按钮前在订单锁内持久化 CREATE、WRITEBACK 或 PAY 标记。两种入口共用该锁及记录。macOS 使用系统 `/usr/bin/lockf` 对继承的文件描述符加锁，父进程持有描述符；进程退出或被终止后由内核释放，未决 JSON 保留。不能在同一批次交替使用不同 stateDir。网络文件系统和多电脑并行执行不在已验证范围内。

创建只从同一固定标题和达人唯一匹配（或内部已经回填的同单 ID）解除未决；回填必须回读任务 ID、商务已下单及指定账户；付款必须读取同单的已付、完成或关闭终态。没有正向证据时保留待对账，绝不由“查不到”“超时”推导可重试。

记录丢失、损坏或未决动作不能靠新批次绕过。若整套运行目录从未迁移，无法仅靠平台零结果证明没有旧动作；迁移须停用旧执行器并复制原记录后再恢复。旧 schema 1 对话状态按恢复线索导入，不能重置未知动作。

## 执行与返回

### 用户明确授权的旧回填恢复

仅在用户明确要求将未完成的旧单作为真实修复测试并继续完成时，ORDER 可传 `writebackRecovery: {orderId, attemptId, externalTaskId, authorizationId, reason}`。必须指向原批次中某笔当前 WRITEBACK 未决尝试；实时核验同一外部合作归属、内部任务仍为空且待商务下单后，保留旧尝试、错误和证据至 writebackRecoveryHistory，消费一次授权，再执行原标准回填。该路径不表示旧尝试已被证明失败，也不是“查不到就重试”。相同授权不能释放后续新未决；禁止用于 CREATE、PAY、preview、其他订单或不同外部合作。Agent 不得自行编造用户授权。

回填最终点击前启用保存请求观察，以内部记录 ID、外部任务 ID 和广告主账户精确匹配 POST。原页面内最多等待 30 秒；收到匹配响应后才进入持久回读。HTTP 拒绝、应用拒绝、网络取消、表单校验失败、没有观察到请求及响应超时分别记录；HTTP 200 且应用 code 200 仅为 ACK，不代替平台持久结果，也不解除未决标记。

每次保存观察的脱敏状态、HTTP／应用数字码和对应 attemptId 持久化到订单记录的 lastActionEvidence，并在结果中返回。不保存请求正文、凭据或后台错误原文。失败后的再次调用只读对账，不能凭 ACK、拒绝或超时重复保存。历史未决记录缺少新字段仍保持防重约束。

每单最多 8 次推进（创建、回填或付款之后重新读平台）；可恢复的页面异常最多恢复 2 次。锁冲突或单单失败进入该单结果，继续其他订单。点击成功返回也不算业务完成；只有平台持久事实算结果。

返回 `orders`、`counts`、`batchRef`、`conversationState`、`phaseComplete`、`paymentComplete`。`decision` 为 COMPLETE、WAITING、PARTIAL 或输入错误 FAILED，不代表所有业务成功；例如全部跳过也可能结束本轮。PREVIEW_READY 表示走查已到最终动作前，phaseComplete 为 false。

平台是业务结果来源，批次记录是授权范围来源，订单记录是防重和恢复线索。新下单／真实付款与点击后中断恢复必须单独取得实际业务证据，技术回归测试不得替代。
